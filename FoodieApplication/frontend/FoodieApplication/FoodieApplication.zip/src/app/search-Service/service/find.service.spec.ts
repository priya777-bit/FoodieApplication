import { TestBed } from '@angular/core/testing';

import { FindService } from './find.service';

describe('FindService', () => {
  let service: FindService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FindService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
