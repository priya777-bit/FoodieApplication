export class Dish {

    restaurantId:string
    dishId:string;
    dishName:string;
    dishType:string;

    constructor()
    {
        this.restaurantId='';
        this.dishId='';
        this.dishName='';
        this.dishType='';
    }
}
