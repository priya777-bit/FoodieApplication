export class Dish {

    dishId:string
    dishName:string
    dishType:string
    restaurantId:string
    imageUrl:string

    constructor(){
        this.dishId='';
        this.dishName='';
        this.dishType='';
        this.restaurantId='';
        this.imageUrl='';
    }
}
