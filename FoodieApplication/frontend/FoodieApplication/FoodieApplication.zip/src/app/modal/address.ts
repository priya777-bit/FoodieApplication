export class Address {
    
        addressType:String="";
        streetNo:String="";
        streetName:String="";
        city:String="";
        state:String="";
        pincode:String="";
        landmark:String="";

}
