import { Address } from "./address";

export class User {
    userMailId:String="";
    userName:String="";
    userPassword:String="";
    userPhoneNo:String="";
    addressList:Array<Address>=[];
}
