export class Login {

    userMailId:String="";
    userPassword:String="";
}
